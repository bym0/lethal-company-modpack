# LC Modpack for friends :)

## Changelog

### 1.0.1
Rm Loud_Horn_Customizer & ChipiChipiLoudHorn, buggy -> causes LoudHorn to permanently activate. Also ChipiChipi Sound does not work.

### 1.0.0
Initial Commit with following Mods:
- "BepInEx-BepInExPack-5.4.2100",
- "2018-LC_API-3.1.0",
- "Suskitech-AlwaysHearActiveWalkies-1.4.3",
- "notnotnotswipez-MoreCompany-1.7.2",
- "x753-More_Suits-1.4.1",
- "Sligili-More_Emotes-1.2.2",
- "tinyhoot-ShipLoot-1.0.0",
- "Sligili-HDLethalCompany-1.5.6",
- "FlipMods-ReservedItemSlotCore-1.6.6",
- "FlipMods-ReservedFlashlightSlot-1.5.1",
- "Suskitech-AlwaysHearActiveWalkies-1.4.3",
- "MetalPipeSFX-HornMoan-2.1.0",
- "Thorlar-HealthStation-1.0.1",
- "RugbugRedfern-Skinwalkers-2.0.1",
- "FlipMods-BetterStamina-1.3.2",
- "malco-Loud_Horn_Customizer-1.0.1",
- "Konahaipper-ChipiChipiLoudHorn-1.0.2",
- "anormaltwig-LateCompany-1.0.7",
- "RickArg-Helmet_Cameras-2.1.5"